<?php

function the_retailer_admin_styles() {
    if ( is_admin() ) {
		wp_enqueue_style('the_retailer_admin_custom', get_template_directory_uri() .'/css/admin/admin-styles.css', false, NULL, 'all');
    }
}
add_action( 'admin_enqueue_scripts', 'the_retailer_admin_styles' );

?>

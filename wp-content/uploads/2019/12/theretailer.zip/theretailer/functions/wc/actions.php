<?php

//-------------------------------------------------------------------
// Archive Products per Row and Page Limits
//-------------------------------------------------------------------
add_action( 'after_setup_theme', 'getbowtied_woocommerce_support' );
function getbowtied_woocommerce_support() {

	add_theme_support( 'woocommerce', array(

    // Product grid theme settings
    'product_grid'        => array(
        'default_rows'    => get_option('woocommerce_catalog_rows', 5),
        'min_rows'        => 2,
        'max_rows'        => '',

        'default_columns' => 4,
        'min_columns'     => 2,
        'max_columns'     => 5,

    	),
	) );
}

?>

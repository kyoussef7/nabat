<?php

// -----------------------------------------------------------------------------
// Define Constants
// -----------------------------------------------------------------------------
define( 'TR_WOOCOMMERCE_IS_ACTIVE', 	class_exists( 'WooCommerce' ) );
define( 'TR_KIRKI_IS_ACTIVE', 			class_exists( 'Kirki' ) );
define( 'TR_WPBAKERY_IS_ACTIVE', 		class_exists( 'Vc_Manager' ) );
define( 'TR_PRODUCT_BLOCKS_IS_ACTIVE', 	defined( 'PBFW_VERSION' ) );
define( 'TR_WISHLIST_IS_ACTIVE', 		class_exists( 'YITH_WCWL' ) );
define( 'TR_WPML_IS_ACTIVE', 			class_exists( 'SitePress' ) );

// ------------------------------------------------------------------
// Theme Name
// ------------------------------------------------------------------
if ( ! function_exists( 'getbowtied_theme_name' ) ) :
function getbowtied_theme_name() {
	$getbowtied_theme = wp_get_theme();
	return $getbowtied_theme->get('Name');
}
endif;

// ------------------------------------------------------------------
// Theme Slug
// ------------------------------------------------------------------
if ( ! function_exists( 'getbowtied_theme_slug' ) ) :
function getbowtied_theme_slug() {
	$getbowtied_theme = wp_get_theme();
	return getbowtied_string_to_slug( $getbowtied_theme->get('Name') );
}
endif;

// ------------------------------------------------------------------
// Theme Author
// ------------------------------------------------------------------
if ( ! function_exists( 'getbowtied_theme_author' ) ) :
function getbowtied_theme_author() {
	$getbowtied_theme = wp_get_theme();
	return $getbowtied_theme->get('Author');
}
endif;

// ------------------------------------------------------------------
// Theme Description
// ------------------------------------------------------------------
if ( ! function_exists( 'getbowtied_theme_description' ) ) :
function getbowtied_theme_description() {
	$getbowtied_theme = wp_get_theme();
	return $getbowtied_theme->get('Description');
}
endif;

//-------------------------------------------------------------------
// Theme Version
//-------------------------------------------------------------------
if ( ! function_exists( 'getbowtied_theme_version' ) ) :
function getbowtied_theme_version() {
	$getbowtied_theme = wp_get_theme(get_template());
	return $getbowtied_theme->get('Version');
}
endif;

// -----------------------------------------------------------------
// String to Slug
// -----------------------------------------------------------------
if ( ! function_exists( 'getbowtied_string_to_slug' ) ) :
function getbowtied_string_to_slug($str) {
	$str = strtolower(trim($str));
	$str = preg_replace('/[^a-z0-9-]/', '_', $str);
	$str = preg_replace('/-+/', "_", $str);
	return $str;
}
endif;

//-------------------------------------------------------------------
// Convert hex to rgb
//-------------------------------------------------------------------
function getbowtied_hex2rgb($hex) {
	$hex = str_replace("#", "", $hex);

	if(strlen($hex) == 3) {
		$r = hexdec(substr($hex,0,1).substr($hex,0,1));
		$g = hexdec(substr($hex,1,1).substr($hex,1,1));
		$b = hexdec(substr($hex,2,1).substr($hex,2,1));
	} else {
		$r = hexdec(substr($hex,0,2));
		$g = hexdec(substr($hex,2,2));
		$b = hexdec(substr($hex,4,2));
	}
	$rgb = array($r, $g, $b);

	return implode(",", $rgb); // returns the rgb values separated by commas
}

//-------------------------------------------------------------------
// String to Bool
//-------------------------------------------------------------------
function theretailer_string_to_bool( $string ) {
    return is_bool( $string ) ? $string : ( 'yes' === $string || 1 === $string || 'true' === $string || '1' === $string );
}

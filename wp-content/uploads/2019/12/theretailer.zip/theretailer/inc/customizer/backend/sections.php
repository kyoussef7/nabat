<?php

Kirki::add_section( 'general', array(
    'title'          => esc_attr__( 'General', 'theretailer' ),
    'priority'       => 1,
    'capability'     => 'edit_theme_options',
) );

Kirki::add_section( 'header', array(
    'title'          => esc_attr__( 'Header', 'theretailer' ),
    'priority'       => 2,
    'capability'     => 'edit_theme_options',
) );

Kirki::add_section( 'footer', array(
    'title'          => esc_attr__( 'Footer', 'theretailer' ),
    'priority'       => 3,
    'capability'     => 'edit_theme_options',
) );

Kirki::add_section( 'blog', array(
    'title'          => esc_attr__( 'Blog', 'theretailer' ),
    'priority'       => 4,
    'capability'     => 'edit_theme_options',
) );

if( TR_WOOCOMMERCE_IS_ACTIVE ) {

    Kirki::add_section( 'shop', array(
        'title'          => esc_attr__( 'Shop', 'theretailer' ),
        'priority'       => 5,
        'capability'     => 'edit_theme_options',
    ) );

    Kirki::add_section( 'product', array(
        'title'          => esc_attr__( 'Product Page', 'theretailer' ),
        'priority'       => 6,
        'capability'     => 'edit_theme_options',
    ) );

}

Kirki::add_section( 'styling', array(
    'title'          => esc_attr__( 'Styling', 'theretailer' ),
    'priority'       => 8,
    'capability'     => 'edit_theme_options',
) );

Kirki::add_section( 'fonts', array(
    'title'          => esc_attr__( 'Fonts', 'theretailer' ),
    'priority'       => 9,
    'capability'     => 'edit_theme_options',
) );

include_once( get_template_directory() . '/inc/customizer/backend/section-general.php' );
include_once( get_template_directory() . '/inc/customizer/backend/section-header.php' );
include_once( get_template_directory() . '/inc/customizer/backend/section-footer.php' );
include_once( get_template_directory() . '/inc/customizer/backend/section-fonts.php' );
include_once( get_template_directory() . '/inc/customizer/backend/section-blog.php' );

if( TR_WOOCOMMERCE_IS_ACTIVE ) {
    include_once( get_template_directory() . '/inc/customizer/backend/section-shop.php' );
    include_once( get_template_directory() . '/inc/customizer/backend/section-product.php' );
}

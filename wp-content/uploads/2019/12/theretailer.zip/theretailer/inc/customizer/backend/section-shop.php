<?php

$section = 'shop';
$sep_id  = 6000;

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'breadcrumbs',
    'label'       => esc_attr__( 'Breadcrumbs', 'theretailer' ),
    'section'     => $section,
    'default'     => false,
    'priority'    => 8
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'dropdown',
    'settings'    => 'catalog_mode_dropdown',
    'section'     => $section,
    'label'       => esc_html__( 'Catalog Mode', 'theretailer' ),
    'priority'    => 10,
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'catalog_mode',
    'label'       => esc_attr__( 'Catalog Mode', 'theretailer' ),
    'description' => esc_html__( 'When enabled, the feature turns off the shopping functionality of WooCommerce by hiding the mini cart in the header and the add-to-cart buttons for products.', 'theretailer' ),
    'section'     => $section,
    'default'     => false,
    'priority'    => 10
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'dropdown',
    'settings'    => 'shop_sidebar_dropdown',
    'section'     => $section,
    'label'       => esc_html__( 'Shop Sidebar', 'theretailer' ),
    'priority'    => 10,
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'sidebar_listing',
    'label'       => esc_attr__( 'Shop Sidebar', 'theretailer' ),
    'section'     => $section,
    'default'     => false,
    'priority'    => 10
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'     => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
    'active_callback'    => array(
        array(
            'setting'  => 'sidebar_listing',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'sidebar_style',
    'label'       => esc_html__( 'Sidebar Style', 'theretailer' ),
    'section'     => $section,
    'default'     => '0',
    'priority'    => 10,
    'choices'     =>  array(
        '0'     => esc_html__('Vertical', 'theretailer'),
        '1'     => esc_html__('Horizontal', 'theretailer')
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'sidebar_listing',
            'operator' => '==',
            'value'    => true,
        ),
    )
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'dropdown',
    'settings'    => 'product_card_dropdown',
    'section'     => $section,
    'label'       => esc_html__( 'Product Card', 'theretailer' ),
    'priority'    => 10,
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'flip_product',
    'label'       => esc_attr__( 'Second Product Image on Hover', 'theretailer' ),
    'section'     => $section,
    'default'     => true,
    'priority'    => 10,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'radio-image',
    'settings'    => 'category_listing',
    'label'       => esc_attr__( 'Parent Category', 'theretailer' ),
    'section'     => $section,
    'default'     => '0',
    'priority'    => 10,
    'choices'     => array(
        '0'   => get_template_directory_uri() . '/inc/customizer/assets/images/category_listing_enabled.png',
        '1'   => get_template_directory_uri() . '/inc/customizer/assets/images/category_listing_disabled.png',
    ),
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'ratings_on_product_listing',
    'label'       => esc_attr__( 'Rating Stars', 'theretailer' ),
    'section'     => $section,
    'default'     => false,
    'priority'    => 10
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'text',
    'settings'    => 'out_of_stock_text',
    'section'     => $section,
    'label'       => esc_html__( 'Out of Stock Badge Text', 'theretailer' ),
    'priority'    => 10,
    'default'     => esc_html__( 'Out of Stock', 'theretailer')
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'text',
    'settings'    => 'sale_text',
    'section'     => $section,
    'label'       => esc_html__( 'Sale Badge Text', 'theretailer' ),
    'priority'    => 10,
    'default'     => esc_html__( 'Sale!', 'theretailer')
));

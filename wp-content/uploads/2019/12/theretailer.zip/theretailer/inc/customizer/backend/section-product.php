<?php

$section = 'product';
$sep_id  = 5000;

// Product Page

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'products_layout',
    'label'       => esc_attr__( 'Product Page Sidebar', 'theretailer' ),
    'section'     => $section,
    'default'     => false,
    'priority'    => 10,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'product_image_zoom',
    'label'       => esc_attr__( 'Product Image Zoom', 'theretailer' ),
    'section'     => $section,
    'default'     => true,
    'priority'    => 10
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'reviews_on_product_page',
    'label'       => esc_attr__( 'Product Reviews', 'theretailer' ),
    'section'     => $section,
    'default'     => true,
    'priority'    => 10
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'related_products_on_product_page',
    'label'       => esc_attr__( 'Related Products', 'theretailer' ),
    'section'     => $section,
    'default'     => true,
    'priority'    => 10
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
    'active_callback'    => array(
        array(
            'setting'  => 'related_products_on_product_page',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'slider',
    'settings'    => 'related_products_number',
    'label'       => esc_html__( 'Number of Related Products', 'theretailer' ),
    'section'     => $section,
    'default'     => 4,
    'priority'    => 10,
    'choices'     => array(
        'min'  => 2,
        'max'  => 12,
        'step' => 1
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'related_products_on_product_page',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

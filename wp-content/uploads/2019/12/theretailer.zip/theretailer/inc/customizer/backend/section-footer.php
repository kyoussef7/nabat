<?php

$section = 'footer';
$sep_id = 3000;

Kirki::add_field( 'theretailer', array(
    'type'        => 'dropdown',
    'settings'    => 'footer_dropdown',
    'section'     => $section,
    'label'       => esc_html__( 'Mobile', 'theretailer' ),
    'priority'    => 10,
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'expandable_footer_mobiles',
    'label'       => esc_attr__( 'Expandable Footer on Mobiles', 'theretailer' ),
    'section'     => $section,
    'default'     => true,
    'priority'    => 10
) );

//==============================================================================
//  Light Footer
//==============================================================================
Kirki::add_field( 'theretailer', array(
    'type'        => 'dropdown',
    'settings'    => 'light_footer_dropdown',
    'section'     => $section,
    'label'       => esc_html__( 'Light Footer', 'theretailer' ),
    'priority'    => 10,
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'light_footer_all_site',
    'label'       => esc_attr__( 'Light Footer', 'theretailer' ),
    'section'     => $section,
    'default'     => true,
    'priority'    => 10,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
    'active_callback'    => array(
        array(
            'setting'  => 'light_footer_all_site',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'radio-image',
    'settings'    => 'light_footer_layout',
    'label'       => esc_attr__( 'Light Footer Layout', 'theretailer' ),
    'section'     => $section,
    'default'     => '4col',
    'priority'    => 10,
    'choices'     => array(
        '4col'   => get_template_directory_uri() . '/inc/customizer/assets/images/light_footer_4_col.png',
        '3col'   => get_template_directory_uri() . '/inc/customizer/assets/images/light_footer_3_col.png',
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'light_footer_all_site',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
    'active_callback'    => array(
        array(
            'setting'  => 'light_footer_all_site',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'color',
    'settings'    => 'primary_footer_bg_color',
    'label'       => esc_attr__( 'Light Footer Background Color', 'theretailer' ),
    'section'     => $section,
    'default'     => '#f4f4f4',
    'priority'    => 10,
    'active_callback'    => array(
        array(
            'setting'  => 'light_footer_all_site',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'color',
    'settings'    => 'primary_footer_color',
    'label'       => esc_attr__( 'Light Footer Text Color', 'theretailer' ),
    'section'     => $section,
    'default'     => '#000',
    'priority'    => 10,
    'active_callback'    => array(
        array(
            'setting'  => 'light_footer_all_site',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

//==============================================================================
//  Dark Footer
//==============================================================================
Kirki::add_field( 'theretailer', array(
    'type'        => 'dropdown',
    'settings'    => 'dark_footer_dropdown',
    'section'     => $section,
    'label'       => esc_html__( 'Dark Footer', 'theretailer' ),
    'priority'    => 10,
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'toggle',
    'settings'    => 'dark_footer_all_site',
    'label'       => esc_attr__( 'Dark Footer', 'theretailer' ),
    'section'     => $section,
    'default'     => true,
    'priority'    => 10,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
    'active_callback'    => array(
        array(
            'setting'  => 'dark_footer_all_site',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'radio-image',
    'settings'    => 'dark_footer_layout',
    'label'       => esc_attr__( 'Dark Footer Layout', 'theretailer' ),
    'section'     => $section,
    'default'     => '4col',
    'priority'    => 10,
    'choices'     => array(
        '4col'   => get_template_directory_uri() . '/inc/customizer/assets/images/dark_footer_4_col.png',
        '3col'   => get_template_directory_uri() . '/inc/customizer/assets/images/dark_footer_3_col.png',
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'dark_footer_all_site',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
    'active_callback'    => array(
        array(
            'setting'  => 'dark_footer_all_site',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'color',
    'settings'    => 'secondary_footer_bg_color',
    'label'       => esc_attr__( 'Dark Footer Background Color', 'theretailer' ),
    'section'     => $section,
    'default'     => '#000',
    'priority'    => 10,
    'active_callback'    => array(
        array(
            'setting'  => 'dark_footer_all_site',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'color',
    'settings'    => 'secondary_footer_color',
    'label'       => esc_attr__( 'Dark Footer Text Color', 'theretailer' ),
    'section'     => $section,
    'default'     => '#fff',
    'priority'    => 10,
    'active_callback'    => array(
        array(
            'setting'  => 'dark_footer_all_site',
            'operator' => '==',
            'value'    => true,
        ),
    )
) );

//==============================================================================
//  Credit Card Icons
//==============================================================================
Kirki::add_field( 'theretailer', array(
    'type'        => 'dropdown',
    'settings'    => 'footer_credit_card_dropdown',
    'section'     => $section,
    'label'       => esc_html__( 'Credit Card Icons', 'theretailer' ),
    'priority'    => 10,
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'image',
    'settings'    => 'footer_logos',
    'section'     => $section,
    'label'       => esc_html__( 'Footer Credit Card Icons', 'theretailer' ),
    'priority'    => 10,
    'default'     => get_template_directory_uri() . '/inc/customizer/assets/images/payment_cards.png'
));

//==============================================================================
//  Copyright Text
//==============================================================================
Kirki::add_field( 'theretailer', array(
    'type'        => 'dropdown',
    'settings'    => 'footer_copyright_dropdown',
    'section'     => $section,
    'label'       => esc_html__( 'Copyright Text', 'theretailer' ),
    'priority'    => 10,
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'textarea',
    'settings'    => 'copyright_text',
    'section'     => $section,
    'label'       => esc_html__( 'Footer Copyright Text', 'theretailer' ),
    'priority'    => 10,
    'default'     => '&#169; <strong>Get Bowtied</strong> - Elite ThemeForest Author'
));

Kirki::add_field( 'theretailer', array(
    'type'        => 'custom',
    'default'      => '<hr />',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'color',
    'settings'    => 'copyright_bar_bg_color',
    'label'       => esc_attr__( 'Copyright Bar Background Color', 'theretailer' ),
    'section'     => $section,
    'default'     => '#000',
    'priority'    => 10,
) );

Kirki::add_field( 'theretailer', array(
    'type'        => 'color',
    'settings'    => 'copyright_text_color',
    'label'       => esc_attr__( 'Copyright Bar Text Color', 'theretailer' ),
    'section'     => $section,
    'default'     => '#a8a8a8',
    'priority'    => 10,
) );
